import { useEffect, useMemo, useRef, useState, type FormEvent } from 'react'
import { api } from './store'
import type { ChatMessage, User } from './types'

// Простой чат «пациент ↔ физиотерапевт». Мок на localStorage,
// на бэкенде — подписка на сообщения по треду.
const fmtTime = (iso: string) => new Date(iso).toLocaleString('ru-RU', { day: 'numeric', month: 'short', hour: '2-digit', minute: '2-digit' })

function Thread({ me, other }: { me: User; other: User }) {
  const [messages, setMessages] = useState<ChatMessage[]>(() => api.messages(me.id, other.id))
  const [text, setText] = useState('')
  const logRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    // «живое» обновление, пока мок: опрашиваем хранилище раз в 3 секунды
    const t = setInterval(() => setMessages(api.messages(me.id, other.id)), 3000)
    return () => clearInterval(t)
  }, [me.id, other.id])

  useEffect(() => {
    logRef.current?.scrollTo({ top: logRef.current.scrollHeight })
  }, [messages.length])

  const send = (e: FormEvent) => {
    e.preventDefault()
    const t = text.trim()
    if (!t) return
    api.sendMessage({ id: crypto.randomUUID(), from: me.id, to: other.id, text: t, createdAt: new Date().toISOString() })
    setText('')
    setMessages(api.messages(me.id, other.id))
  }

  return (
    <div className="chat">
      <div className="chat-log" ref={logRef} aria-live="polite">
        {messages.length === 0 && <p className="chat-empty">Напишите первое сообщение — {other.name ?? other.email} ответит здесь.</p>}
        {messages.map((m) => (
          <div key={m.id} className={'bubble ' + (m.from === me.id ? 'mine' : 'theirs')}>
            {m.text}
            <span className="time">{fmtTime(m.createdAt)}</span>
          </div>
        ))}
      </div>
      <form className="chat-form" onSubmit={send}>
        <input value={text} maxLength={1000} placeholder="Сообщение…" onChange={(e) => setText(e.target.value)} aria-label="Сообщение" />
        <button className="btn primary" type="submit">Отправить</button>
      </form>
    </div>
  )
}

export default function Chat({ user }: { user: User }) {
  const all = useMemo(() => api.users(), [])
  const therapists = all.filter((u) => u.role === 'therapist')
  const patients = all.filter((u) => u.role === 'patient')
  const [otherId, setOtherId] = useState<string>('')

  const candidates = user.role === 'therapist' ? patients : therapists
  const other = candidates.find((u) => u.id === otherId) ?? candidates[0]

  if (candidates.length === 0) {
    return (
      <section>
        <h1>Чат</h1>
        <p className="hint">Пока нет собеседников: {user.role === 'therapist' ? 'в системе ещё нет пациентов' : 'физиотерапевт ещё не зарегистрирован'}.</p>
      </section>
    )
  }

  return (
    <section>
      <div className="head">
        <h1>Чат</h1>
        <label className="mini">{user.role === 'therapist' ? 'Пациент' : 'Физиотерапевт'}
          <select value={other?.id ?? ''} onChange={(e) => setOtherId(e.target.value)}>
            {candidates.map((u) => <option key={u.id} value={u.id}>{u.name ?? u.email}</option>)}
          </select>
        </label>
      </div>
      {other ? <Thread me={user} other={other} /> : null}
    </section>
  )
}
