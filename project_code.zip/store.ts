import type { Assignment, ChatMessage, CustomExercise, PatientComment, Role, User, WeightEntry, Workout } from './types'

// Мок-слой вместо бэкенда: данные лежат в localStorage.
// При подключении сервера заменить тела функций на fetch-запросы, сигнатуры оставить.
const K = {
  users: 'hf_users',
  session: 'hf_session',
  workouts: (id: string) => `hf_workouts_${id}`,
  customEx: 'hf_custom_exercises',
  assignments: 'hf_assignments',
  comments: 'hf_comments',
  chat: 'hf_chat',
  weights: (id: string) => `hf_weights_${id}`,
}

function read<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}
const write = (key: string, value: unknown) => localStorage.setItem(key, JSON.stringify(value))

async function hash(text: string): Promise<string> {
  const buf = await crypto.subtle.digest('SHA-256', new TextEncoder().encode(text))
  return Array.from(new Uint8Array(buf)).map((b) => b.toString(16).padStart(2, '0')).join('')
}

export const RESET_CODE = '123456' // демо-код восстановления

// Демо-аккаунты для ролей (пароль у всех: demo1234)
// Чтобы попасть в кабинет физиотерапевта или админку без бэкенда.
const DEMO_PASSWORD = 'demo1234'
async function seedDemoUsers() {
  const users = read<User[]>(K.users, [])
  const demo: { email: string; role: Role; name: string }[] = [
    { email: 'therapist@demo.ru', role: 'therapist', name: 'Иван Петров, физиотерапевт' },
    { email: 'admin@demo.ru', role: 'admin', name: 'Администратор' },
  ]
  let changed = false
  for (const d of demo) {
    if (!users.some((u) => u.email === d.email)) {
      users.push({ id: crypto.randomUUID(), email: d.email, hash: await hash(DEMO_PASSWORD), role: d.role, name: d.name, consentAt: new Date().toISOString() })
      changed = true
    }
  }
  if (changed) write(K.users, users)
}

export const api = {
  current(): User | null {
    const id = localStorage.getItem(K.session)
    return read<User[]>(K.users, []).find((u) => u.id === id) ?? null
  },
  users(): User[] {
    return read<User[]>(K.users, [])
  },
  async register(email: string, password: string, role: Role = 'patient', name?: string): Promise<User> {
    await seedDemoUsers()
    const users = read<User[]>(K.users, [])
    if (users.some((u) => u.email === email.toLowerCase())) throw new Error('Аккаунт с такой почтой уже есть')
    const user: User = { id: crypto.randomUUID(), email: email.toLowerCase(), hash: await hash(password), role, name: name?.trim() || undefined }
    write(K.users, [...users, user])
    localStorage.setItem(K.session, user.id)
    return user
  },
  async login(email: string, password: string): Promise<User> {
    await seedDemoUsers()
    const user = read<User[]>(K.users, []).find((u) => u.email === email.toLowerCase())
    if (!user || user.hash !== (await hash(password))) throw new Error('Неверная почта или пароль')
    localStorage.setItem(K.session, user.id)
    return user
  },
  logout() {
    localStorage.removeItem(K.session)
  },
  async resetPassword(email: string, code: string, password: string): Promise<void> {
    if (code !== RESET_CODE) throw new Error('Неверный код')
    const users = read<User[]>(K.users, [])
    const idx = users.findIndex((u) => u.email === email.toLowerCase())
    if (idx < 0) throw new Error('Аккаунт не найден')
    users[idx] = { ...users[idx], hash: await hash(password) }
    write(K.users, users)
  },
  save(user: User) {
    write(K.users, read<User[]>(K.users, []).map((u) => (u.id === user.id ? user : u)))
  },
  workouts(userId: string): Workout[] {
    return read<Workout[]>(K.workouts(userId), [])
  },
  saveWorkouts(userId: string, list: Workout[]) {
    write(K.workouts(userId), list)
  },

  // --- Свои упражнения (админка) ---
  customExercises(): CustomExercise[] {
    return read<CustomExercise[]>(K.customEx, [])
  },
  saveCustomExercise(ex: CustomExercise) {
    write(K.customEx, [ex, ...read<CustomExercise[]>(K.customEx, [])])
  },
  deleteCustomExercise(id: string) {
    write(K.customEx, read<CustomExercise[]>(K.customEx, []).filter((e) => e.id !== id))
  },

  // --- Назначения физиотерапевта ---
  assignments(patientId?: string): Assignment[] {
    const all = read<Assignment[]>(K.assignments, [])
    return patientId ? all.filter((a) => a.patientId === patientId) : all
  },
  assign(a: Assignment) {
    write(K.assignments, [a, ...read<Assignment[]>(K.assignments, [])])
  },
  unassign(id: string) {
    write(K.assignments, read<Assignment[]>(K.assignments, []).filter((a) => a.id !== id))
  },

  // --- Комментарии к пациентам ---
  comments(patientId: string): PatientComment[] {
    return read<PatientComment[]>(K.comments, []).filter((c) => c.patientId === patientId)
  },
  addComment(c: PatientComment) {
    write(K.comments, [...read<PatientComment[]>(K.comments, []), c])
  },
  deleteComment(id: string) {
    write(K.comments, read<PatientComment[]>(K.comments, []).filter((c) => c.id !== id))
  },

  // --- Чат ---
  // Переписка хранится парой «отправитель:получатель» — на бэкенде заменить на единый тред.
  messages(userA: string, userB: string): ChatMessage[] {
    return read<ChatMessage[]>(K.chat, [])
      .filter((m) => (m.from === userA && m.to === userB) || (m.from === userB && m.to === userA))
      .sort((a, b) => a.createdAt.localeCompare(b.createdAt))
  },
  sendMessage(m: ChatMessage) {
    write(K.chat, [...read<ChatMessage[]>(K.chat, []), m])
  },

  // --- Дневник веса и калоража ---
  weights(userId: string): WeightEntry[] {
    return read<WeightEntry[]>(K.weights(userId), []).sort((a, b) => a.date.localeCompare(b.date))
  },
  addWeight(userId: string, entry: WeightEntry) {
    const list = read<WeightEntry[]>(K.weights(userId), []).filter((e) => e.date !== entry.date)
    write(K.weights(userId), [...list, entry])
  },
  removeWeight(userId: string, date: string) {
    write(K.weights(userId), read<WeightEntry[]>(K.weights(userId), []).filter((e) => e.date !== date))
  },
}
