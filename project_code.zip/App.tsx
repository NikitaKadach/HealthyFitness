import Brand from './Brand'
import { useEffect, useState } from 'react'
import Auth from './Auth'
import Consent from './Consent'
import Questionnaire from './Questionnaire'
import Legends from './Legends'
import Health from './Health'
import Chat from './Chat'
import Therapist from './Therapist'
import Admin from './Admin'
import { Builder, ExerciseList, WorkoutList } from './Workouts'
import { api } from './store'
import { useTheme } from './theme'
import type { Role, User, Workout } from './types'

// Все разделы приложения. Поле roles — кому раздел доступен (защита маршрутов).
type Tab = 'workouts' | 'exercises' | 'legends' | 'health' | 'chat' | 'profile' | 'builder' | 'patients' | 'admin'
const TABS: { id: Tab; label: string; roles: Role[] }[] = [
  { id: 'workouts', label: 'Тренировки', roles: ['patient'] },
  { id: 'exercises', label: 'Упражнения', roles: ['patient', 'therapist', 'admin'] },
  { id: 'legends', label: 'Золотая эра', roles: ['patient', 'therapist', 'admin'] },
  { id: 'health', label: 'Здоровье', roles: ['patient'] },
  { id: 'chat', label: 'Чат', roles: ['patient', 'therapist'] },
  { id: 'patients', label: 'Мои пациенты', roles: ['therapist'] },
  { id: 'admin', label: 'База упражнений', roles: ['admin'] },
  { id: 'profile', label: 'Анкета', roles: ['patient', 'therapist', 'admin'] },
]
const DEFAULT_TAB: Record<Role, Tab> = { patient: 'workouts', therapist: 'patients', admin: 'admin' }
const allowed = (tab: Tab, role: Role) => TABS.some((t) => t.id === tab && t.roles.includes(role))

const ROLE_LABEL: Record<Role, string> = { patient: 'Пациент', therapist: 'Физиотерапевт', admin: 'Админ' }

function ThemeToggle() {
  const [theme, toggle] = useTheme()
  return (
    <button className="theme-toggle" onClick={toggle} title={theme === 'dark' ? 'Светлая тема' : 'Тёмная тема'} aria-label="Переключить тему">
      {theme === 'dark' ? '☀' : '☾'}
    </button>
  )
}

export default function App() {
  const [user, setUser] = useState<User | null>(() => api.current())
  const [tab, setTab] = useState<Tab>(() => {
    const u = api.current()
    return u ? DEFAULT_TAB[u.role] : 'workouts'
  })
  const [custom, setCustom] = useState<Workout[]>(() => {
    const u = api.current()
    return u ? api.workouts(u.id) : []
  })

  // Защита разделов: раздел, недоступный роли, сбрасывается на дефолтный
  useEffect(() => {
    if (user && !allowed(tab, user.role)) setTab(DEFAULT_TAB[user.role])
  }, [user, tab])

  const update = (u: User) => { api.save(u); setUser(u) }
  const logout = () => { api.logout(); setUser(null); setTab('workouts') }
  const login = (u: User) => { setUser(u); setTab(DEFAULT_TAB[u.role]); setCustom(api.workouts(u.id)) }
  const saveCustom = (list: Workout[]) => { setCustom(list); if (user) api.saveWorkouts(user.id, list) }

  if (!user) return <Auth onAuth={login} />
  if (!user.consentAt) return <Consent onAccept={() => update({ ...user, consentAt: new Date().toISOString() })} onDecline={logout} />
  // Анкета обязательна только для пациентов: физиотерапевт и админ работают с данными других
  if (!user.profile && user.role === 'patient') return <Questionnaire first onSave={(profile) => update({ ...user, profile })} />

  const conditions = user.profile?.conditions ?? []

  return (
    <div className="shell">
      <header className="top">
        <Brand />
        <nav aria-label="Разделы">
          {TABS.filter((t) => t.roles.includes(user.role)).map((t) => (
            <button key={t.id} className={'nav' + (tab === t.id || (t.id === 'workouts' && tab === 'builder') ? ' active' : '')} onClick={() => setTab(t.id)}>{t.label}</button>
          ))}
        </nav>
        <span className="user-chip">
          <span className="role-badge">{ROLE_LABEL[user.role]}</span>
          <ThemeToggle />
          <button className="link" onClick={logout}>Выйти</button>
        </span>
      </header>
      <main className={'content' + (tab === 'builder' || tab === 'patients' || tab === 'admin' ? ' wide' : '')}>
        {tab === 'workouts' && (
          <WorkoutList user={user} custom={custom} conditions={conditions} onCreate={() => setTab('builder')} onDelete={(id) => saveCustom(custom.filter((w) => w.id !== id))} />
        )}
        {tab === 'exercises' && <ExerciseList isAdmin={user.role === 'admin'} conditions={conditions} />}
        {tab === 'legends' && <Legends />}
        {tab === 'health' && user.profile && <Health user={user} />}
        {tab === 'chat' && <Chat user={user} />}
        {tab === 'patients' && <Therapist therapist={user} />}
        {tab === 'admin' && <Admin admin={user} />}
        {tab === 'builder' && (
          <Builder conditions={conditions} onCancel={() => setTab('workouts')} onSave={(w) => { saveCustom([w, ...custom]); setTab('workouts') }} />
        )}
        {tab === 'profile' && (
          <Questionnaire
            first={false}
            initial={user.profile}
            onSave={(profile) => update({ ...user, profile })}
            onRevoke={user.role === 'patient' ? () => update({ ...user, consentAt: undefined, profile: undefined }) : undefined}
          />
        )}
      </main>
    </div>
  )
}
