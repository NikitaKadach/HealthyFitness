import { useMemo, useState, type FormEvent } from 'react'
import { WORKOUTS } from './data'
import { api } from './store'
import type { Assignment, User } from './types'

// Кабинет физиотерапевта: список пациентов, просмотр анкеты,
// назначение тренировок, комментарии.

const fmt = (iso: string) => new Date(iso).toLocaleString('ru-RU', { day: 'numeric', month: 'short', year: 'numeric' })

function AssignForm({ therapist, patientId, onDone }: { therapist: User; patientId: string; onDone: () => void }) {
  const custom = api.workouts(therapist.id)
  const library = [...custom, ...WORKOUTS]
  const [workoutId, setWorkoutId] = useState(library[0]?.id ?? '')
  const [comment, setComment] = useState('')
  const workout = library.find((w) => w.id === workoutId)

  const submit = (e: FormEvent) => {
    e.preventDefault()
    if (!workout) return
    const a: Assignment = {
      id: crypto.randomUUID(),
      patientId,
      therapistId: therapist.id,
      workout,
      comment: comment.trim() || undefined,
      createdAt: new Date().toISOString(),
    }
    api.assign(a)
    setComment('')
    onDone()
  }

  return (
    <form className="panel" style={{ maxWidth: 'none', border: '1px solid var(--line)', borderRadius: 'var(--r)', padding: '1rem', background: 'var(--paper)' }} onSubmit={submit}>
      <h2 style={{ margin: 0 }}>Назначить тренировку</h2>
      <label>Тренировка
        <select value={workoutId} onChange={(e) => setWorkoutId(e.target.value)}>
          {custom.length > 0 && <optgroup label="Мои тренировки">{custom.map((w) => <option key={w.id} value={w.id}>{w.title}</option>)}</optgroup>}
          <optgroup label="Готовые программы">{WORKOUTS.map((w) => <option key={w.id} value={w.id}>{w.title}</option>)}</optgroup>
        </select>
      </label>
      <label>Комментарий пациенту (необязательно)
        <textarea rows={2} maxLength={500} value={comment} placeholder="Например: начните с 2 подходов, следите за пульсом" onChange={(e) => setComment(e.target.value)} />
      </label>
      <button className="btn primary" type="submit" disabled={!workout}>Назначить</button>
    </form>
  )
}

function PatientView({ therapist, patient }: { therapist: User; patient: User }) {
  const [, force] = useState(0)
  const refresh = () => force((n) => n + 1)
  const assignments = api.assignments(patient.id)
  const comments = api.comments(patient.id)
  const [text, setText] = useState('')

  const addComment = (e: FormEvent) => {
    e.preventDefault()
    const t = text.trim()
    if (!t) return
    api.addComment({ id: crypto.randomUUID(), patientId: patient.id, authorId: therapist.id, text: t, createdAt: new Date().toISOString() })
    setText('')
    refresh()
  }

  const p = patient.profile

  return (
    <div className="patient-view">
      <div className="head">
        <h1 style={{ fontSize: '1.5rem' }}>{patient.name ?? patient.email}</h1>
        <a className="link" href={`mailto:${patient.email}`}>{patient.email}</a>
      </div>

      <div className="notice" role="note">
        <p><strong>Анкета</strong>{p ? '' : ' не заполнена пациентом'}</p>
        {p && (
          <>
            <p>{p.sex === 'male' ? 'Мужской' : 'Женский'} пол · {p.height} см · {p.weight} кг · род. {p.birth}</p>
            <p>Цель: {p.goal || 'не указана'}</p>
            {p.conditions.length > 0 && <p>Противопоказания и особенности: {p.conditions.join('; ')}</p>}
            {p.notes && <p>Жалобы и пожелания: {p.notes}</p>}
          </>
        )}
      </div>

      <AssignForm therapist={therapist} patientId={patient.id} onDone={refresh} />

      <div>
        <h2>Назначенные тренировки</h2>
        {assignments.length === 0 && <p className="hint">Пациенту пока ничего не назначено.</p>}
        <ul className="list">
          {assignments.map((a) => (
            <li key={a.id}>
              <div className="list-row" style={{ cursor: 'default' }}>
                <span className="name">{a.workout.title}</span>
                <span className="meta">{a.workout.items.length} упр. · {fmt(a.createdAt)}</span>
                <button className="link danger-link" onClick={() => { api.unassign(a.id); refresh() }}>Отменить</button>
              </div>
              {a.comment && <p className="detail" style={{ paddingBottom: '.6rem' }}>Комментарий: {a.comment}</p>}
            </li>
          ))}
        </ul>
      </div>

      <div>
        <h2>Комментарии</h2>
        <form className="row" style={{ marginBottom: '.75rem' }} onSubmit={addComment}>
          <input style={{ flex: 1 }} value={text} maxLength={500} placeholder="Новый комментарий (виден только вам)" onChange={(e) => setText(e.target.value)} />
          <button className="btn" type="submit">Добавить</button>
        </form>
        {comments.length === 0 && <p className="hint">Комментариев нет. Здесь удобно фиксировать наблюдения по пациенту.</p>}
        {comments.map((c) => (
          <div className="comment-item" key={c.id}>
            <p className="desc" style={{ margin: 0 }}>{c.text}</p>
            <div className="meta">
              <span>{fmt(c.createdAt)}</span>
              <button className="link danger-link" onClick={() => { api.deleteComment(c.id); refresh() }}>Удалить</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}

export default function Therapist({ therapist }: { therapist: User }) {
  const patients = useMemo(() => api.users().filter((u) => u.role === 'patient'), [])
  const [selectedId, setSelectedId] = useState<string>('')
  const patient = patients.find((u) => u.id === selectedId) ?? patients[0]

  return (
    <section>
      <h1>Мои пациенты</h1>
      {patients.length === 0 ? (
        <p className="hint">В системе пока нет пациентов. Как только кто-то зарегистрируется с ролью «Пациент», он появится в этом списке.</p>
      ) : (
        <div className="two-col">
          <aside className="side-list">
            <ul className="list">
              {patients.map((u) => (
                <li key={u.id}>
                  <button className={'list-row' + (patient?.id === u.id ? ' active' : '')} onClick={() => setSelectedId(u.id)}>
                    <span className="name">{u.name ?? u.email}</span>
                    <span className="meta">{u.profile ? 'анкета ✓' : 'анкета —'}</span>
                  </button>
                </li>
              ))}
            </ul>
          </aside>
          {patient && <PatientView therapist={therapist} patient={patient} />}
        </div>
      )}
    </section>
  )
}
