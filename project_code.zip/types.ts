export type Sex = 'male' | 'female'
export type Role = 'patient' | 'therapist' | 'admin'
export interface Profile {
  height: number
  weight: number
  sex: Sex
  birth: string
  conditions: string[]
  notes: string
  goal: string
}
export interface User {
  id: string
  email: string
  hash: string
  role: Role
  name?: string
  consentAt?: string
  profile?: Profile
}
export interface Exercise {
  id: string
  name: string
  bodyPart: string
  equipment: string
  target: string
  secondary: string[]
  image: string
  gif: string
  // Свои поля: упражнения из админки несут своё описание и видео
  description?: string
  video?: string
  custom?: boolean
}
// Упражнение, добавленное админом: видео и описание свои
export interface CustomExercise {
  id: string
  name: string
  bodyPart: string
  equipment: string
  target: string
  description: string
  videoUrl: string
  createdBy: string
  createdAt: string
}
export interface WorkoutItem { exerciseId: string; sets: number; reps: number }
export interface Workout { id: string; title: string; description?: string; items: WorkoutItem[]; custom?: boolean }
// Тренировка, назначенная физиотерапевтом пациенту
export interface Assignment {
  id: string
  patientId: string
  therapistId: string
  workout: Workout
  comment?: string
  createdAt: string
}
// Комментарий физиотерапевта к пациенту
export interface PatientComment {
  id: string
  patientId: string
  authorId: string
  text: string
  createdAt: string
}
export interface ChatMessage {
  id: string
  from: string
  to: string
  text: string
  createdAt: string
}
// Запись веса для статистики прогресса
export interface WeightEntry {
  date: string // YYYY-MM-DD
  weight: number
  kcal?: number // фактический калораж дня (необязательно)
}
export type Lang = 'ru' | 'en' | 'es' | 'it' | 'tr' | 'zh' | 'hi' | 'pl' | 'ko' | 'fr'
